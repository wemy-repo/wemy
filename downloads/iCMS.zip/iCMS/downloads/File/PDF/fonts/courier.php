<?php
/**
 * @package File_PDF
 */
for ($i = 0; $i <= 255; $i++) {
    $font_widths['courier'][chr($i)] = 600;
}
