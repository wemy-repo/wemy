<?php

session_start();
$counter_name = "BattSaver.deb.txt";
 
include "../config.php";

// Check if a text file exists. If not create one and initialize it to zero.
if (!file_exists($counter_name)) {
  $f = fopen($counter_name, "w");
  fwrite($f,"0");
  fclose($f);

$q = "INSERT INTO download (filename, views) VALUES
		('downloads/BattSaver.deb', 1)";

$statresult = mysql_query($q);

}
 
// Read the current value of our counter file
$f = fopen($counter_name,"r");
$counterVal = fread($f, filesize($counter_name));
fclose($f);



// Has visitor been counted in this session?
// If not, increase counter value by one
if(!isset($_SESSION['BattSaver.deb'])){
  $_SESSION['BattSaver.deb']="yes";
  $counterVal++;
  $f = fopen($counter_name, "w");
  fwrite($f, $counterVal);
  fclose($f); 

$q = "UPDATE download SET views = views + 1 WHERE filename = 'downloads/BattSaver.deb'";

$statresult = mysql_query($q);

}

?>
	
	
	<!DOCTYPE html>
<html>
<head>
	<title>BattSaver.deb</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.1/jquery.mobile-1.3.1.min.css" />
	<link rel="stylesheet" href="_css/style.css" />
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.1/jquery.mobile-1.3.1.min.js"></script>
</head>
<body>
	

	

	
<!-- MAIN PAGE -->
<div data-role="page" id="front" class="depiction" data-title="Details">
<center>
  <br>
  <img src="_img/nzb.png" width="290" height="150"></center>

	<div data-role="content">
		<ul data-role="listview" data-inset="true">

<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=597655&bid=1491393" type="text/javascript"></SCRIPT>
<noscript><a href="http://www.bidvertiser.com">internet marketing</a></noscript>

			<li data-role="list-divider">General</li>
		    <li><a href="#info" target="_blank"><img src="_img/info.svg" alt="Info" class="ui-li-icon">Info</a></li>
		    <li><a href="#screens" target="_blank"><img src="_img/screens.svg" alt="Screenshots" class="ui-li-icon">Screenshots</a></li>
            <li><a href="#stats" target="_blank"><img src="_img/stats.svg" alt="Statistics" class="ui-li-icon">Statistics</a></li>
		</ul>
		<ul data-role="listview" data-inset="true">
			<li data-role="list-divider">Help</li>			
		    <li><a href="#instructions" target="_blank"><img src="_img/nb.svg" alt="instructions" class="ui-li-icon">Info and Help</a></li>
		    <li><a href="#faq" target="_blank"><img src="_img/question.svg" alt="FAQ" class="ui-li-icon">FAQ</a></li>
		</ul>
		<ul data-role="listview" data-inset="true">
			<li data-role="list-divider">About</li>			
		    <li><a href="#authors" target="_blank"><img src="_img/profile.svg" alt="Authors" class="ui-li-icon ui-corner-none">Contact Repo</a></li>
		    <li><a href="#contribute" target="_blank"><img src="_img/heart.svg" alt="Contribute" class="ui-li-icon">Social</a></li>
		</ul>
		<ul data-role="listview" data-inset="true">
			<li data-role="list-divider">Support us. Thanks:)</li>
			<li>
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
					<input type="hidden" name="cmd" value="_s-xclick">
					<table>
					<tr><td><select name="os0">
						<option>Amount</option>
						<option value="2,50">&euro; 2,50</option>
                        <option value="5,00">&euro; 5,00</option>
                        <option value="7,50">&euro; 7,50</option>
                        <option value="10,00">&euro; 10,00</option>
                        <option value="15,00">&euro; 15,00</option>
                        <option value="20,00">&euro; 20,00</option>
                        <option value="20,00">&euro; 25,00</option>
					</select> </td></tr>
					</table>
					<input type="hidden" name="currency_code" value="EUR">
					<input type="hidden" name="hosted_button_id" value="9TCAXQBKN84J8">
					<input id="ppimg" type="image" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
					<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
					<a id="ppcss" data-role="button" data-theme="e"><i>Donate Now</i></a>
					<img id="pppretty" width="250px" src="_img/paypal.jpg" border="0" alt="PayPal Acceptance Mark">
				</form>
						</li>
		</ul>
	  <p style="text-align:center;padding-bottom: 5px;padding-top: 0px;text-shadow: none;"><span style="font-size: 12px;">
              Your IP:<?php
            echo $ip  =$_SERVER['REMOTE_ADDR'];
          ?>
           <br>Your Device is a 
          <?php
            echo $device = $_SERVER["HTTP_X_MACHINE"];
          ?>
          <br>Running on iOS 
          <?php
            $text =  $_SERVER["HTTP_USER_AGENT"]; 
            preg_match('/OS ([_0-9]+)/', $text, $res);
            $version = isset($res[1])?str_replace('_','.',$res[1]):null;
            echo $version;
          ?>
<br>
<a href="http://damarist.de" target="_blank">POWERED BY Repo CMS</a>
</span></p>
	  </div>
</div>




<!-- INFO -->
<div data-role="page" id="info" class="depiction" data-title="General">
	<div data-role="content">
		<ul data-role="listview" data-inset="true">
			<li data-role="list-divider">General info:</li>
			<li>
				<p style="word-wrap: break-word;"></p>
          <p>no description atm</p>
          <p></p>
				
			</li>
			<li data-role="list-divider">Changes:</li>
			<li>
				<p style="word-wrap: break-word;"></p>
          <p>no description atm</p>
          <p></p>
			</li>
			<li data-role="list-divider">Compatibility:</li>
			<li>
				<p style="word-wrap: break-word;"></p>
          <p>no description atm</p>
          <p></p>
			</li>
		</ul>
        </div>
</div>





<!-- SCREENSHOTS -->
<div data-role="page" id="screens" class="depiction" data-title="Screenshots">
	<div data-role="content">
		<center>
        <img class="ss" src="_ss/BattSaver.deb_1.png" width="90%" />
		<img class="ss" src="_ss/BattSaver.deb_2.png" width="90%" />
		<img class="ss" src="_ss/BattSaver.deb_3.png" width="90%" />
		<img class="ss" src="_ss/BattSaver.deb_4.png" width="90%" />
		<img class="ss" src="_ss/BattSaver.deb_5.png" width="90%" />
		<img class="ss" src="_ss/BattSaver.deb_6.png" width="90%" />
		</center>
        </div>
</div>





<!-- STATISTICS -->
<div data-role="page" id="stats" class="depiction" data-title="Statistics">
	<div data-role="content">
	    <ul data-role="listview" data-inset="true">
		    <li>
			  <center>
			  Downloads:
<?php

include "../config.php";

$sql="SELECT filename, stats, dldate FROM download WHERE filename = 'downloads/BattSaver.deb' ";
     $res=mysql_query($sql) or die(mysql_error()); 
     $daten=mysql_fetch_array($res);  
	 
      echo  $daten['stats'] . "<BR><BR>Last Download: "; 
      echo  $daten['dldate'] . "<BR><BR>Views: ";
	  echo  $counterVal;
?>
			  </center>
		    </li>
	      </ul>
        </div>
</div>




<!-- INSTRUCTIONS -->
<div data-role="page" id="instructions" class="depiction" data-title="Support">
	<div data-role="content">
		<ul data-role="listview" data-inset="true">
			  <li data-role="list-divider">Support</li>
			<li><a href="http://your-domain.de" target="_blank">
				<h1>Forum</h1>
				<p>Visit our forum for general support.</p>
			</a></li>
			<li><a href="http://your-domain.de" target="_blank">
				<h1>Registration</h1>
				<p>To acces our forum you need to register, you can register from here.</p>
			</a></li>
		</ul>
		<ul data-role="listview" data-inset="true">
		  <li data-role="list-divider">Discussion</li>
			<li><a href="http://your-domain.de" target="_blank">
				<h1>Thread</h1>
				<p>More instructions and pro tips</p>
				<p>Here you can discus ask anything about the repo, cydia, tweaks etc etc....</p>
			</a></li>
			<li><a href="http://your-domain.de" target="_blank">
				<h1>Tools</h1>
				<p>Here you can find almost any tool you need for your iDevice<br>
				  <br>
				</p>
			</a></li>
		</ul>
        </div>
</div>





<!-- FAQ -->
<div data-role="page" id="faq" class="depiction" data-title="FAQ">
	<div data-role="content">
		<ul data-role="listview" data-inset="true">
			<li data-role="list-divider">FAQ</li>
			<li>
				<h1>Warning</h1>
				<p>Theres no way that damarist.de or damar1st.de is responsible for any damage both software and hardware, using the repo is at your own risk.</p>
			</li>
			<li>
				<h1>Our pollicy</h1>
				<p>If you like a tweak after trying it a while and you like it... <br>
				</p>
				<p>Consider to buy it!!</p>
			</li>
		</ul>
	</div>
</div>






<!-- AUTHORS -->
<div data-role="page" id="authors" class="depiction" data-title="Repo Manager">
    <div data-role="content">
        <ul data-role="listview" data-inset="true">
		<li>
			<img class="profilepic" src="_img/avatar_678.jpg">
			<h2>damar1st and iMart79</h2>
			<p>Admin, Repo Manager, iFreak etc etc...</p>
		</li>
		<li><a href="mailto:your@email.de" target="_blank"><img src="_img/mail.svg" alt="Info" class="ui-li-icon"> Questions?? Ask me.</a></li>
		<li><a href="http://your-domain.de" target="_blank"><img src="_img/al.svg" alt="Info" class="ui-li-icon">http://your-domain.de</a></li>
	</ul>            
    </div>
</div>





<!-- CONTRIBUTE -->
<div data-role="page" id="contribute" class="depiction" data-title="Social">
	<div data-role="content">
		<ul data-role="listview" data-inset="true">
			<li data-role="list-divider">We are Social</li>
            <li><a href="http://twitter.com/share?text=damar1st%20Cydia%20Repo&url=http://www.cydia.damarist.de" target="_blank"><img src="_img/twitter.svg" alt="Info" class="ui-li-icon">Tweet</a></li>
			<li><a href="https://www.facebook.com/sharer/sharer.php?u=http://www.nzb4you.com/repo" target="_blank"><img src="_img/facebook.svg" alt="Info" class="ui-li-icon">Share with friends</a></li>
			</li>
		</ul>
        </div>
</div>




</body>
</html>