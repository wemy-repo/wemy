<?php 
ob_start();
session_start();
error_reporting(0);

require_once ("../config.php");


if (isset($_SESSION['admin']) === true) 
{
include("header.php");
}
else 
{
}

if (isset($_SESSION['mod']) === true)
{
include("header2.php");
}
else
{
}

if (isset($_SESSION['admin']))

{

?>

<div></div>
			
			
			<div class="row-fluid">
				<div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-info-sign"></i>Add User</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">Add User
					 <div class="clearfix"></div>
					 </div>
					 </div>
					 </div>
					

<h1>Add a new user</h1> 
<form action="user2.php" method="post"> 
    Username:<br /> 
    <input type="text" name="username" value="" /> 
    <br /><br /> 
    E-Mail:<br /> 
    <input type="text" name="email" value="" /> 
    <br /><br /> 
    Password:<br /> 
    <input type="password" name="password" value="" /> 
    <br /><br /> 


 <select name="game" size="1">
      <option value="admin">Admin</option>
      <option value="mod">Moderator</option>
    </select>

  <br /><br /> 
    <input type="submit" value="Register" /> 
</form>

<?php

$result = mysql_query("SELECT * FROM register ORDER BY dldate ASC");

//echo "<div style='float:left; overflow-x:Scroll; width:920px;'>";
echo "<table border='1' align='center' overflow-x:Scroll>";
echo "<tr> <th> nickname </th> <th> email </th> <th> website </th> <th> date </th> </tr>";

while($row = mysql_fetch_array($result)) {

$trimed1 = str_replace("downloads/", "", $row[filename]);
$trimed2 = str_replace(".deb", "", $trimed1);

echo '<tr> <td> '.$row[nickname].' </td> <td> '.$row[email].' </td> <td> '.$row[website].' </td> <td> '.$row[dldate].' </td></tr>';

}

echo "</table>"



}
include('footer.php');

?>