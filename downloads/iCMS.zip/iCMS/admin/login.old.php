<?php

ob_start();
error_reporting(0);

session_start();

require_once ("../config.php");





$no_visible_elements=true;
 


$getaction = $_GET['act'];
if ($getaction == "logout") {

	session_destroy('admin');
   session_destroy('mod');
	header("Location: login.php");
}


if (isset($_SESSION['admin']) or ($_SESSION['mod']))
{
header("Location: index.php");
}
else {
?>

<?php

include('header.php');

?>

			<div class="row-fluid">
				<div class="span12 center login-header">
					<h2>Repo Admin</h2>
				</div><!--/span-->
			</div><!--/row-->
			
			<div class="row-fluid">
				<div class="well span5 center login-box">
					<div class="alert alert-info">
						Please login with your Username and Password.
					</div>
					<form method="POST" target="_self">
						<fieldset>
							<div class="input-prepend" title="Username" data-rel="tooltip">
								<span class="add-on"><i class="icon-user"></i></span><input autofocus class="input-large span10" name="username" id="username" type="text" value="" />
							</div>
							<div class="clearfix"></div>

							<div class="input-prepend" title="Password" data-rel="tooltip">
								<span class="add-on"><i class="icon-lock"></i></span><input class="input-large span10" name="password" id="password" type="password" value="" />
							</div>
							<div class="clearfix"></div>

							<p class="center span5">
							<button type="submit" name="submit" class="btn btn-primary">Login</button>
							</p>
						</fieldset>
					</form>
				</div><!--/span-->
			</div><!--/row-->
			
<?php 
$submit = $_POST['submit'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql="SELECT * FROM users WHERE username = '$username'";

     $res=mysql_query($sql) or die(mysql_error()); 

     $daten=mysql_fetch_array($res);  

$pass = $daten[password];
$salt = $daten[salt];
$usertype = $daten[usertype];

        $passwd = hash('sha256', $password . $salt); 
        for($round = 0; $round < 65536; $round++) 
        { 
            $password2 = hash('sha256', $passwd . $salt); 
        }




if($password2 === $pass && $usertype == 'admin')
{
$_SESSION['admin'] = true;

print "logged in successfully<br>";
header("Location: index.php");
}
else
{

}
if($password2 === $pass && $usertype == 'mod')
{
$_SESSION['mod'] = true;

print "logged in successfully<br>";
header("Location: index.php");
}
else
{

}

//print "logged in successfully<br>";
//header("Location: index.php");

}

ob_end_flush();

include('footer.php'); ?>
