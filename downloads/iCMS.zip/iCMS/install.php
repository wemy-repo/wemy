<?php
header("Location: ./install/");
?>
